Self: [https://medium.com/p/cf851f0f588/edit](https://medium.com/p/cf851f0f588/edit)   
Status: draft  
Version: **0.1**

---

# My Scuba Diving experience in Raja Ampat..

.. and how I couldn't resist coding a Ruby on Rails scooby app

---

In October '22, my ❤️ wife allowed me to go scuba diving by myself in Raja Ampat, consider the paradise for divers.![image]([article]scuba--jo09uvup59g.jpg)

A beautiful and rare animal who could be extinct in a few decades, and beside him a beautiful sea turtle in[ Sauwandarek](https://www.google.com/maps/place/Sauwandarek+Village/@-0.5858766,130.6122214,13.42z/data=!4m13!1m7!3m6!1s0x2d5c3eaaccb47097:0x7851bd844c4cdf44!2sIsole+Raja+Ampat!3b1!8m2!3d-1.0320468!4d130.5052176!3m4!1s0x0:0xf11684dad6130be3!8m2!3d-0.5903592!4d130.6023098) village

### The trip

![image]([article]scuba--rn7opz2oo.jpg)

This is Raja Ampat, west of Indonesia

### The bungalow

![image]([article]scuba--tnomzk5zfnr.jpg)

This is Wai island

## My typical day

I would wake up between 5 and 6. At 5, the light would strat spreading, and at 530 the electricity would be available

-  05:00

#### The app

I started scuba diving in the morning and

#### The diving

![image]([article]scuba--4rx3qr0wnkk.jpg)

![image]([article]scuba--4kl75dqag8l.jpg)

Riccardo saying hi to a Wobbegong!

#### Around Wai island

aaa![image]([article]scuba--7qqeh3owtge.jpg)

Congee and I in Piaynemo

![image]([article]scuba--92kef42brna.jpg)

Pyaynemo, the must go-to destination for your RA trip.

![image]([article]scuba--4s5obbog0je.jpg)

![image]([article]scuba--ks67tanqqui.jpg)

#### The learning

![image]([article]scuba--jo2nuuxek58.jpg)

#### Conclusions

![image]([article]scuba--n82h94fc7s.jpg)